/********************************************************************
 Copyright (C) 2002 Shinobu Yoshimura, University of Tokyo,
 the Japan Society for the Promotion of Science (JSPS)
 All Rights Reserved
 *********************************************************************/

/* hashtable.cc : hash bucket class definition in integer space */

#if 0
#define WH_COVERAGE_ENABLED
#endif

#include "hashtable.h"



/* class WH_HashBucket */



/* not covered yet
 */
