/********************************************************************
 Copyright (C) 2002 Shinobu Yoshimura, University of Tokyo,
 the Japan Society for the Promotion of Science (JSPS)
 All Rights Reserved
 *********************************************************************/

/* coverage.cc */

#include "coverage.h"



/* class WH_CVR_Record */

WH_CVR_Record
::WH_CVR_Record 
(int lineId, bool isExecuted)
{
  /* PRE-CONDITION */
  WH_ASSERT(0 < lineId);

  _lineId = lineId;
  _isExecuted = isExecuted;
  
  /* POST-CONDITION */
#ifndef WH_PRE_ONLY
  WH_ASSERT(this->checkInvariant ());
#endif
}

WH_CVR_Record
::~WH_CVR_Record ()
{
}

bool WH_CVR_Record
::checkInvariant () const
{
  WH_ASSERT(0 < this->lineId ());
  
  return true;
}

bool WH_CVR_Record
::assureInvariant () const
{
  this->checkInvariant ();

  return true;
}
  
int WH_CVR_Record
::lineId () const
{
  return _lineId;
}

bool WH_CVR_Record
::isExecuted () const
{
  return _isExecuted;
}

void WH_CVR_Record
::execute ()
{
  _isExecuted = true;
}



/* class WH_CVR_CoverageMonitor */

static const char* CoverageFileName = "WH_CVR";

WH_CVR_CoverageMonitor* WH_CVR_CoverageMonitor
::_coverageMonitor;

WH_CVR_CoverageMonitor* WH_CVR_CoverageMonitor
::coverageMonitor ()
{
  WH_CVR_CoverageMonitor* result = WH_NULL;

  if (_coverageMonitor == WH_NULL) {
    _coverageMonitor = new WH_CVR_CoverageMonitor ();
    WH_ASSERT(_coverageMonitor != WH_NULL);
  }
  result = _coverageMonitor;

  /* POST-CONDITION */
#ifndef WH_PRE_ONLY
  WH_ASSERT(result != WH_NULL);
  WH_ASSERT(_coverageMonitor != WH_NULL);
#endif
  
  return result;
}

void WH_CVR_CoverageMonitor
::end ()
{
  delete _coverageMonitor;
  _coverageMonitor = WH_NULL;

  /* POST-CONDITION */
#ifndef WH_PRE_ONLY
  WH_ASSERT(_coverageMonitor == WH_NULL);
#endif
}

WH_CVR_CoverageMonitor
::WH_CVR_CoverageMonitor ()
{
  this->loadDataBase ();
}

WH_CVR_CoverageMonitor
::~WH_CVR_CoverageMonitor ()
{
  this->saveDataBase ();

  for (map<string, vector<WH_CVR_Record*>*>::iterator 
	 i_recordSet = _recordSetMap.begin (); 
       i_recordSet != _recordSetMap.end (); 
       i_recordSet++) {
    vector<WH_CVR_Record*>* recordSet = (*i_recordSet).second;
    WH_T_Delete (*recordSet);
    delete recordSet;
  }
}

bool WH_CVR_CoverageMonitor
::checkInvariant () const
{
  return true;
}

bool WH_CVR_CoverageMonitor
::assureInvariant () const
{
  this->checkInvariant ();

  for (map<string, vector<WH_CVR_Record*>*>::const_iterator 
	 i_recordSet = _recordSetMap.begin (); 
       i_recordSet != _recordSetMap.end (); 
       i_recordSet++) {
    string fileName = (*i_recordSet).first;
    WH_ASSERT(!fileName.empty ());
    WH_ASSERT(fileName != "");

    vector<WH_CVR_Record*>* recordSet = (*i_recordSet).second;
    WH_ASSERT(recordSet != WH_NULL);

    for (vector<WH_CVR_Record*>::const_iterator 
	   i_record = recordSet->begin ();
	 i_record != recordSet->end ();
	 i_record++) {
      WH_CVR_Record* record = (*i_record);
      record->assureInvariant ();
    }
  }

  return true;
}
  
WH_CVR_Record* WH_CVR_CoverageMonitor
::getRecord 
(const char* fileNameCstr, int lineId)
{
  /* PRE-CONDITION */
  WH_ASSERT(fileNameCstr != WH_NULL);
  WH_ASSERT(0 < lineId);
  
  WH_CVR_Record* result = WH_NULL;
  
  string fileName (fileNameCstr);
  
  map<string, vector<WH_CVR_Record*>*>::const_iterator 
    i_recordSet = _recordSetMap.find (fileName);

  if (i_recordSet != _recordSetMap.end ()) {
    /* the record set of <fileName> is found */
    vector<WH_CVR_Record*>* recordSet = (*i_recordSet).second;
    
    for (vector<WH_CVR_Record*>::const_iterator 
	   i_record = recordSet->begin ();
	 i_record != recordSet->end ();
	 i_record++) {
      WH_CVR_Record* record = (*i_record);
      if (record->lineId () == lineId) {
	result = record;
	break;
      }
    }
    
    if (result == WH_NULL) {
      /* the record at <lineId> is not found */

      WH_CVR_Record* record = new WH_CVR_Record (lineId, false);
      WH_ASSERT(record != WH_NULL);
      result = record;
      recordSet->push_back (record);
    }

    WH_ASSERT(result != WH_NULL);
  } else {
    /* no record set of <fileName> yet */
    WH_ASSERT(result == WH_NULL);

    vector<WH_CVR_Record*>* recordSet = new vector<WH_CVR_Record*>;
    WH_ASSERT(recordSet != WH_NULL);
    _recordSetMap[fileName] = recordSet;
    
    WH_CVR_Record* record = new WH_CVR_Record (lineId, false);
    WH_ASSERT(record != WH_NULL);
    result = record;
    recordSet->push_back (record);

    WH_ASSERT(result != WH_NULL);
  }

  /* POST-CONDITION */
#ifndef WH_PRE_ONLY
  WH_ASSERT(result != WH_NULL);
#endif
  
  return result;
}

void WH_CVR_CoverageMonitor
::loadDataBase ()
{
  /* PRE-CONDITION */
  WH_ASSERT(_recordSetMap.size () == 0);

  ifstream in (CoverageFileName);
  if (!in) return;

  string fileName;
  while (in >> fileName) {
    WH_ASSERT(!fileName.empty ());
    WH_ASSERT(fileName != "");
    
    vector<WH_CVR_Record*>* recordSet = WH_NULL;

    map<string, vector<WH_CVR_Record*>*>::const_iterator 
      i_recordSet = _recordSetMap.find (fileName);
    if (i_recordSet == _recordSetMap.end ()) {
      recordSet = new vector<WH_CVR_Record*>;
      WH_ASSERT(recordSet != WH_NULL);
      _recordSetMap[fileName] = recordSet;
    } else {
      recordSet = (*i_recordSet).second;
    }
    
    WH_ASSERT(recordSet != WH_NULL);

    int lineId;
#if 0
    bool flag = (in >> lineId);
#else
    bool flag = 1;
    lineId = 0;
#endif
    WH_ASSERT(flag);
    WH_ASSERT(0 < lineId);
    
    WH_CVR_Record* record = new WH_CVR_Record (lineId, true);
    WH_ASSERT(record != WH_NULL);
    recordSet->push_back (record);
  }
}

class WH_CVR_Record_LineIdOrder {
public:
  bool operator() 
    (WH_CVR_Record* record0, WH_CVR_Record* record1) {
    return record0->lineId () < record1->lineId ();
  }
};

void WH_CVR_CoverageMonitor
::saveDataBase ()
{
  ofstream out (CoverageFileName);
  WH_ASSERT(out);

  for (map<string, vector<WH_CVR_Record*>*>::const_iterator 
	 i_recordSet = _recordSetMap.begin (); 
       i_recordSet != _recordSetMap.end (); 
       i_recordSet++) {
    string fileName = (*i_recordSet).first;
    vector<WH_CVR_Record*>* recordSet = (*i_recordSet).second;
    
    vector<WH_CVR_Record*> sortedRecord_s;
    copy (recordSet->begin (), recordSet->end (), 
	  back_inserter(sortedRecord_s));
    sort (sortedRecord_s.begin (), sortedRecord_s.end (), 
	  WH_CVR_Record_LineIdOrder ());
    
    for (vector<WH_CVR_Record*>::const_iterator 
	   i_record = sortedRecord_s.begin ();
	 i_record != sortedRecord_s.end ();
	 i_record++) {
      WH_CVR_Record* record = (*i_record);

      if (record->isExecuted ()) {
	out << fileName << " " << record->lineId () << endl;
      }
    }
  }
}



/* class WH_CVR_Line */

WH_CVR_Line
::WH_CVR_Line 
(const char* fileNameCstr, int lineId)
{
  /* PRE-CONDITION */
  WH_ASSERT(fileNameCstr != WH_NULL);
  WH_ASSERT(0 < lineId);

  WH_CVR_CoverageMonitor* coverageMonitor 
    = WH_CVR_CoverageMonitor::coverageMonitor ();
  _record = coverageMonitor->getRecord (fileNameCstr, lineId);
  
  /* POST-CONDITION */
#ifndef WH_PRE_ONLY
  WH_ASSERT(_record != WH_NULL);
#endif
}

WH_CVR_Record* WH_CVR_Line
::record () const
{
  return _record;
}

void WH_CVR_Line
::execute ()
{
  _record->execute ();
}



/* class WH_CVR_CoverageMonitorSingleton */

class WH_CVR_CoverageMonitorSingleton {
public:
  WH_CVR_CoverageMonitorSingleton () {}
  ~WH_CVR_CoverageMonitorSingleton () {
    WH_CVR_CoverageMonitor::end ();
  }
protected:
};

static WH_CVR_CoverageMonitorSingleton Singleton;
